<?php

namespace Database\Seeders;

use Illuminate\Database\Seeder;
use Illuminate\Support\Facades\DB;

class DatabaseSeeder extends Seeder
{
    /**
     * Seed the application's database.
     *
     * @return void
     */
    public function run()
    {
        $this->call([
            ConstantTypeSeeder::class,
            UserSeeder::class,
            PermissionSeeder::class,
        ]);

        if (!DB::table('quran_surahs')->exists()) {
            $this->call(QuranSeeder::class);
        }
    }
}
