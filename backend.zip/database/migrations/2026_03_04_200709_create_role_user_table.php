<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('role_user', function (Blueprint $table) {
            $table->morphs('authorizable');
            $table->foreignId('role_id')->constrained('roles')->cascadeOnDelete();
            $table->nullableMorphs('scope');

            // $table->primary(['authorizable_id', 'authorizable_type', 'role_id'], 'role_user_primary');
            $table->primary(
                ['authorizable_id', 'authorizable_type', 'role_id'],
                'role_user_primary'
            );
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        // Schema::dropindexIfExists('role_user_scope_type_scope_id_index');
        Schema::dropIfExists('role_user');
    }
};
