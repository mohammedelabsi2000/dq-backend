<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration {
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::table('halaqa_statuses', function (Blueprint $table) {
            $table->string('sponsor_entity')->nullable()->comment('جهة الكفالة');
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::table('halaqa_statuses', function (Blueprint $table) {
            $table->dropColumn('sponsor_entity');
        });
    }
};
