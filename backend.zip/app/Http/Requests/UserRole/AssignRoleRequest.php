<?php

namespace App\Http\Requests\UserRole;


use Illuminate\Validation\Rule;
use App\Http\Requests\DQFormRequest;
use App\Models\Halaqa;
use App\Models\User;
use App\Models\UserScope;

class AssignRoleRequest extends DQFormRequest
{
    public function authorize(): bool
    {
        return $this->user()->hasPermissionTo('users.roles.update', 'sanctum');
    }

    public function rules(): array
    {
        return [
            'role_ids'   => 'required|array',
            'role_ids.*' => 'required|integer|exists:roles,id',
            'scopes'        => 'sometimes|array',
            'scopes.*.type' => [
                'required_with:scopes',
                'string',
                Rule::in(['branch', 'region', 'center', 'halaqa']),
            ],
            'scopes.*.id'   => 'required_with:scopes|integer',
        ];
    }

    public function messages(): array
    {
        return [
            'role_ids.required'   => 'الأدوار مطلوبة',
            'role_ids.array'      => 'الأدوار يجب أن تكون مصفوفة',
            'role_ids.*.required' => 'معرف الدور مطلوب',
            'role_ids.*.integer'  => 'معرف الدور يجب أن يكون رقماً',
            'role_ids.*.exists'   => 'الدور غير موجود',
            'scopes.array'        => 'النطاقات يجب أن تكون مصفوفة',
            'scopes.*.type.required_with' => 'نوع النطاق مطلوب عند إرسال النطاقات',
            'scopes.*.type.string'  => 'نوع النطاق يجب أن يكون نصاً',
            'scopes.*.type.in'    => 'نوع النطاق غير صالح',
            'scopes.*.id.required_with' => 'معرف النطاق مطلوب عند إرسال النطاقات',
            'scopes.*.id.integer' => 'معرف النطاق يجب أن يكون رقماً',
        ];
    }

    protected function prepareForValidation()
    {
        $scopes = [];

        if ($this->has('scopes')) {
            foreach ($this->scopes as $scope) {
                $scopes[] = is_string($scope) ? json_decode($scope, true) : $scope;
            }
        }

        $this->merge(['scopes' => $scopes]);
    }

    /**
     * منع تنسيب أكثر من مستخدم كمحفظ فعّال لنفس الحلقة في آن واحد.
     */
    public function withValidator($validator): void
    {
        $validator->after(function ($validator) {
            $routeUser = $this->route('user');
            $userId = $routeUser instanceof User ? $routeUser->id : (int) $routeUser;

            foreach ((array) $this->input('scopes', []) as $index => $scope) {
                if (($scope['type'] ?? null) !== 'halaqa' || empty($scope['id'])) {
                    continue;
                }

                $halaqaId = (int) $scope['id'];

                $existingTeacherScope = UserScope::where('scope_type', 'halaqa')
                    ->where('scope_id', $halaqaId)
                    ->where('user_id', '!=', $userId)
                    ->active()
                    ->first();

                if (!$existingTeacherScope) {
                    continue;
                }

                $halaqa = Halaqa::find($halaqaId);

                if ($halaqa) {
                    $location = $halaqa->locationLabel();
                    $message = "هذه الحلقة \"{$halaqa->name}\" يوجد لها محفظ بالفعل" . ($location ? " ({$location})" : '') . '.';

                    $validator->errors()->add("scopes.$index.id", $message);
                }
            }
        });
    }
}
